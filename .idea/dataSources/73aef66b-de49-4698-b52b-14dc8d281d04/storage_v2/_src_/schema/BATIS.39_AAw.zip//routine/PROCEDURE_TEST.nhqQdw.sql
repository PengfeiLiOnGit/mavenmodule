create PROCEDURE PROCEDURE_TEST (
    var_ename in VARCHAR2
--  返回cursor 出参   
--    lists OUT SYS_REFCURSOR
)AS 
    user_row sys_user%rowtype;
    -- 定义一个游标
    CURSOR sys_users is SELECT
        *
    FROM sys_user;
BEGIN
    DBMS_OUTPUT.PUT_LINE (var_ename);    
    for item in sys_users loop
        DBMS_OUTPUT.PUT_LINE (item.user_name);    
        update sys_user set user_name = user_name || 'P1' WHERE ID = ITEM.ID;
    end loop;
--    查询参数
--    open lists for select * from sys_user;
END PROCEDURE_TEST;
/

